<?php 
header('Location: ../..');
?>