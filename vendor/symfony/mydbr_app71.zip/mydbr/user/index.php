<?php 
header('Location: ..');
?>